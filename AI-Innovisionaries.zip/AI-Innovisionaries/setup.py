from setuptools import find_packages, setup

setup(
    name = 'me3dicBot',
    version= '0.0.0',
    author= 'Gufran',
    author_email= 'gufranamu2004@gmail',
    packages= find_packages(),
    install_requires = []

)